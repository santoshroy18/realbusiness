#!/bin/bash
tmux new-session -d -s my_sessionsanty 'node bot.js'